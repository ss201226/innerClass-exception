package anonymous;

public class Cat extends Animal {

	@Override
	void move() {
		// TODO Auto-generated method stub
		
	}

	
   
}
