package anonymous;

public abstract class Animal {
	abstract void move();
	
}
