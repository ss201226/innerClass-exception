package army;

public class SoldierAdapter implements Soldier{

	@Override
	public void eat() {}

	@Override
	public void work() {}

	@Override
	public void sleep() {}

	@Override
	public void hello() {}

}
