package army;

public class Private implements Soldier{

	@Override
	public void eat() {
		System.out.println("�Ļ�");
		
	}

	@Override
	public void work() {
		System.out.println("�̰����� �پ�ٴϱ�");
		
	}

	@Override
	public void sleep() {
		System.out.println("�ܴ�");
		
	}

	@Override
	public void hello() {
		System.out.println("��!!��!!");
		
	}

}
