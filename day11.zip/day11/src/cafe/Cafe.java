package cafe;

public interface Cafe {
	String[] getMenu();
	int[] getPrice();
	void sell(String menu);
	
}
